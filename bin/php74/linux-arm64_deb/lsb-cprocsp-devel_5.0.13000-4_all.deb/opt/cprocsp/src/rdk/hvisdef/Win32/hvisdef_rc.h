//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by hvisdef_rc.rc
//
#define IDS_TIME_SEC_1                  558
#define IDS_TIME_x1                     559
#define IDS_TIME_x2_4                   560
#define IDS_TIME_x5_9                   561
#define IDS_CERTIFICATE                 562
#define IDS_SUBJECT                     563
#define IDS_ISSUER                      564
#define IDS_HASH_UNKNOWN                565
#define IDS_HASH_LENGTH                 566
#define IDS_UNKNOWN_HASH_VALUE          567
#define IDS_UNKNOWN_DATA                568
#define IDS_UNKNOWN_DATA_BIG            569
#define IDS_VALID_FROM                  569
#define IDS_WRAPPED_DATA                570
#define IDS_INTERNAL_CP_TEST            571
#define IDS_UNKNOWN_WRAPPED_DATA        572
#define IDS_VALID_TO                    573
#define IDS_SERIAL_NUMBER               574
#define IDS_REQUEST_CERT                575
#define IDS_WRAPPED_CERTIFICATE         576
#define IDS_WRAPPED_REQUEST_CERT        577
#define IDS_THIS_UPDATE                 578
#define IDS_NEXT_UPDATE                 579
#define IDS_REV_NUMBERS                 580
#define IDS_AUTHENTICATION              581
#define IDS_SAN                         582
#define IDS_IAN                         583
#define IDI_HVDEF                       4096
#define IDS_HVDEF_NAME                  0x1000
#define IDS_HVDEF_NICKNAME              0x1001
#define IDS_HVDEF_DETAIL_NAME           0x1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
