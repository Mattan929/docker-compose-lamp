#if !defined( _READER_RDR_VER_H )
#define _READER_RDR_VER_H

#ifdef __cplusplus 
extern "C" {
#endif //__cplusplus 
DWORD info_versionsupport(
    TSupSysContext *context, TSupSysInfo *info );
#ifdef __cplusplus 
}
#endif //__cplusplus 

#endif /* !defined( _READER_RDR_VER_H ) */
