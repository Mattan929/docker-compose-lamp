# xer2print initialization script (sh)

if [ -d /opt/cprocsp/xer2print ]; then
	export XER2PRINT_XSL_PATH=/opt/cprocsp/xer2print/;
	export XER2PRINT_DEFAULT_PRINT_FORMAT=dvi;
	export XER2PRINT_DEFAULT_PRINT_SERVICE=kdvi;
fi
